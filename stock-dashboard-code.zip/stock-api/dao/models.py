from sqlalchemy import Column, Integer, String, Float, Date, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship  

# Create the Base class for model definitions
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    name = Column(String)

class Portfolio(Base):
    __tablename__ = 'portfolio'

    id = Column(Integer, primary_key=True, index=True)  # Unique identifier for each portfolio entry
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)  # Reference to the user
    stock_symbol = Column(String, index=True)  # Stock symbol (e.g., 'AAPL')
    quantity = Column(Integer, nullable=False)  # Quantity of shares bought
    purchase_price = Column(Float, nullable=False)  # Price at which the stock was bought
    purchase_date = Column(Date, nullable=False)  # Date of purchase

    # Relationships can be added here if needed
    user = relationship("User", back_populates="portfolios")

# If you have a relationship in User model
User.portfolios = relationship("Portfolio", order_by=Portfolio.id, back_populates="user")

