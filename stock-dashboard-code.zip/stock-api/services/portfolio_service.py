from datetime import datetime
from dao.models import Portfolio, User
from pydantic_model.forms import UserCreate, StockRecord, PortfolioRecord
from dataaccess import user_da, portfolio_da
from services.stock_service import get_current_stock_price

def create_user(user_data: UserCreate):
    new_user = User(
                email=user_data.email,
                name=user_data.name
            )
    user_da.create_user(new_user)
   
def retrieve_portfolio(email: str):    
    user_id = user_da.retrieve_user_id(email)
    portfolio_list: list[Portfolio] = portfolio_da.retrieve_portfolio(user_id)
    portfolio_records = [PortfolioRecord.model_validate(record) for record in portfolio_list]
    for record in portfolio_records:
        record.current_price = get_current_stock_price(record.stock_symbol)
        record.gains_loss = (record.current_price - record.purchase_price) * record.quantity
    return portfolio_records   

def create_portfolio(stock_record: StockRecord, email: str):
    user_id = user_da.retrieve_user_id(email)
    portfolio = Portfolio(user_id=user_id, **stock_record.model_dump())
    portfolio_da.create_portfolio(portfolio)

def sell_stock(stock_record: StockRecord, email: str):
    try:
        user_id = user_da.retrieve_user_id(email)
        portfolio_item = portfolio_da.get_portfolio_item(user_id, stock_record.stock_symbol)

        if not portfolio_item:
            raise ValueError(f"Stock {stock_record.stock_symbol} not found in user's portfolio")

        if portfolio_item.quantity < stock_record.quantity:
            raise ValueError(f"Insufficient shares. You only have {portfolio_item.quantity} shares of {stock_record.stock_symbol}")

        # Calculate the profit/loss for this sale
        profit_loss = (stock_record.purchase_price - portfolio_item.purchase_price) * stock_record.quantity

        # Calculate new quantity
        new_quantity = portfolio_item.quantity - stock_record.quantity

        if new_quantity == 0:
            # If all shares are sold, remove the stock from the portfolio
            portfolio_da.delete_portfolio_item(portfolio_item)
        else:
            # Calculate new average purchase price
            total_value = (portfolio_item.quantity * portfolio_item.purchase_price) - (stock_record.quantity * portfolio_item.purchase_price)
            new_average_price = total_value / new_quantity

            # Update the portfolio with the new quantity and average price
            portfolio_item.quantity = new_quantity
            portfolio_item.purchase_price = new_average_price
            portfolio_da.update_portfolio_item(portfolio_item)

        return {
            "message": f"Successfully sold {stock_record.quantity} shares of {stock_record.stock_symbol}",
            "profit_loss": profit_loss,
            "new_quantity": new_quantity,
            "new_average_price": new_average_price if new_quantity > 0 else None
        }

    except Exception as e:
        raise e

# Main execution
if __name__ == "__main__":
    # create portfolio record
    stock_record = StockRecord(
        stock_symbol="AAPL",
        quantity=100,
        purchase_price=150.0,
        purchase_date=datetime.now().date()
    )
    create_portfolio(stock_record, "vreddy2020@gmail.com")

    # Get top gainers
    records = retrieve_portfolio("vreddy2020@gmail.com")
    print(records)