import pandas as pd
import yfinance as yf
import os
from datetime import datetime, timedelta

def get_sp500_tickers():
    # URL of the S&P 500 constituents
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"

    # Read the table directly from the webpage
    sp500_df = pd.read_html(url)[0]

    # Get the tickers column
    sp500_tickers = sp500_df['Symbol'].tolist()
    return sp500_tickers

def fetch_and_store_today_data(tickers):
    """Fetch stock data for each ticker and store in a CSV file."""
    data_list = []
    today = datetime.now().date()  # Get today's date

    # Define the cache directory
    cache_dir = './cache'
    # Check if data is returned

    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)

# Cache file paths
    today_cache_file = f'{cache_dir}/{today.isoformat()}_data.csv'        
    
    for ticker in tickers:
        try:
            stock_data = yf.download(ticker, period='1d')
            if not stock_data.empty:
                # Append the ticker data as a dictionary
                data_list.append({
                    'Ticker': ticker,
                    'Close': stock_data['Close'].iloc[-1],
                    'Open': stock_data['Open'].iloc[-1],
                    'High': stock_data['High'].iloc[-1],
                    'Low': stock_data['Low'].iloc[-1],
                    'Volume': stock_data['Volume'].iloc[-1]
                })
        except Exception as e:
            pass

    # Convert list of dictionaries to a DataFrame
    data_df = pd.DataFrame(data_list)
    save_to_cache(today_cache_file, data_df)
    return data_df

def get_current_stock_price(ticker: str):
    stock_data = yf.download(ticker, period='1d')
    price = 0
    if not stock_data.empty:
        price = stock_data['Close'].iloc[-1]
    return price

def load_cached_data(cache_file):
    """Load data from the cache file if it exists."""
    if os.path.exists(cache_file):
        return pd.read_csv(cache_file)
    return None

def save_to_cache(cache_file, data):
    """Save the DataFrame to the cache file in a long format."""
    os.makedirs('stock-api/cache', exist_ok=True)  # Ensure cache directory exists
    data.to_csv(cache_file, index=False)

def get_top_sp500_stocks(gainers=True,top_n=10):
    tickers = get_sp500_tickers()
    today = datetime.now().date()  # Get today's date
    yesterday = today - timedelta(days=1)  # Calculate yesterday's date

    # Cache file paths
    today_cache_file = f'./cache/{today.isoformat()}_data.csv'
    yesterday_cache_file = f'./cache/{yesterday.isoformat()}_data.csv'

    # Load today's data if it exists
    today_data = load_cached_data(today_cache_file)

    if today_data is None:
        print("Today's data not found, fetching data...")
        # Fetch data for the specified tickers for the last day
        today_data = fetch_and_store_today_data(tickers)

    # Load yesterday's data
    yesterday_data = load_cached_data(yesterday_cache_file)

    # Create a list to store top gainers or losers
    top_stocks = []

    # Iterate over the tickers to calculate price changes
    for ticker in tickers:
        # Ensure both today and yesterday data are available
        if (today_data['Ticker'].isin([ticker]).any()) and (yesterday_data is not None and yesterday_data['Ticker'].isin([ticker]).any()):
            try:
                current_price = round(today_data[today_data['Ticker'] == ticker]['Close'].iloc[0], 2)
                previous_close = round(yesterday_data[yesterday_data['Ticker'] == ticker]['Close'].iloc[0], 2)  # Use yesterday's close

                # Calculate the price change percentage
                if previous_close > 0:  # Avoid division by zero
                    price_change = (current_price - previous_close) / previous_close * 100
                    price_change = round(price_change, 2)

                    top_stocks.append({
                        'symbol': ticker,
                        'name': ticker,
                        'price': current_price,
                        'previous_close': previous_close,
                        'change_percentage': price_change
                    })
            except Exception as e:
                print(f"Error fetching data for {ticker}: {e}")
                continue  # Skip this ticker if an error occurs

    # Create a DataFrame
    stocks_df = pd.DataFrame(top_stocks)

    # Sort by change percentage in descending order for gainers
    # Sort by change percentage in ascending order for losers
    # Sort based on gainers or losers
    if gainers:
        #top_stocks_sorted = sorted(top_stocks, key=lambda x: x['change_percentage'], reverse=True)[:top_n]
        top_stocks_sorted = stocks_df.sort_values(by='change_percentage', ascending=False).head(top_n)
    else:
        top_stocks_sorted = stocks_df.sort_values(by='change_percentage', ascending=True).head(top_n)

    print(f"Returning {len(top_stocks_sorted)} records")

    # Convert to dictionary
    top_stocks_sorted = top_stocks_sorted.to_dict(orient='records')
    return top_stocks_sorted[:5]

# Main execution
if __name__ == "__main__":
    # Get top gainers
    top_gainers = get_top_sp500_stocks()
    print("Top Gainers in S&P 500:")
    print(top_gainers[:10])
