import os
import databases
from sqlalchemy import create_engine
from orm.models import Base

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # Get the current directory of the script
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'test.db')}"  # Reference the test.db file in the same folder


# Create a database instance
database = databases.Database(DATABASE_URL)

# Create the engine
engine = create_engine(DATABASE_URL)

def retrieve_tables():
    # return list of tabes in the database
    return list(Base.metadata.tables.keys())

def create_db_tables():
    """Creates all tables defined in the metadata."""
    Base.metadata.create_all(engine)
    print("All database tables created.")

def drop_all_tables():
    """Drops all tables defined in the metadata."""
    Base.metadata.drop_all(engine)
    print("All database tables dropped.")

def drop_table(table_name: str):
    """Drops a specific table by name."""
    table = Base.metadata.tables.get(table_name)
    if table is not None:
        table.drop(engine)
        print(f"Table '{table_name}' dropped.")
    else:
        print(f"Table '{table_name}' does not exist.")

def create_specific_table(table_name: str):
    """Creates a specific table by name."""
    table = Base.metadata.tables.get(table_name)
    if table is not None:
        table.create(engine)
        print(f"Table '{table_name}' created.")
    else:
        print(f"Table '{table_name}' does not exist in metadata.")

if __name__ == "__main__":
    # Example usage
    drop_all_tables()
    create_db_tables()
    print(retrieve_tables())
