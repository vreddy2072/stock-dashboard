import secrets
print(secrets.token_hex(32))  # Generates a 64-character hexadecimal string