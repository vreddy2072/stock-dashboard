# dependencies.py
import os
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="")  

# Secret key and algorithm for JWT
SECRET_KEY = os.getenv('SECRET_KEY')
ALGORITHM = "HS256"

def get_current_user_email(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")  # Ensure this matches how you set up your token
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        # Here, you could also fetch user from the database if needed
        return email  # Return the email of the current user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
