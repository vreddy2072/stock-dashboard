from pydantic import BaseModel
from typing import Optional  # Import Optional
from datetime import date  # {{ edit_1 }}

class UserCreate(BaseModel):
    email: str
    name: Optional[str] = None  # Make name optional

class StockRecord(BaseModel):
    stock_symbol: str
    purchase_price: float
    quantity: int
    purchase_date: date

class PortfolioRecord(BaseModel):
    class Config:
        from_attributes = True
    stock_symbol: str
    purchase_price: float
    current_price: Optional[float] = None  # Make this optional
    quantity: int
    purchase_date: date
    gains_loss: Optional[float] = None  # Make this optional
