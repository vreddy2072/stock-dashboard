from sqlalchemy.orm import Session
from dao.models import Portfolio
from database.database import SessionLocal
from sqlalchemy.exc import SQLAlchemyError

def retrieve_portfolio(user_id: str):    
    db: Session = SessionLocal()
    try:
        portfolio_list: list[Portfolio] = db.query(Portfolio).filter(Portfolio.user_id == user_id).all()
        return portfolio_list
    finally:
        db.close()

def create_portfolio(portfolio: Portfolio):
    db: Session = SessionLocal()
    try:
        db.add(portfolio)
        db.commit()
        db.refresh(portfolio)
    finally:
        db.close()

def get_portfolio_item(user_id: int, stock_symbol: str) -> Portfolio:
    db: Session = SessionLocal()
    try:
        return db.query(Portfolio).filter(
            Portfolio.user_id == user_id,
            Portfolio.stock_symbol == stock_symbol
        ).first()
    finally:
        db.close()

def update_portfolio_item(portfolio_item: Portfolio):
    db: Session = SessionLocal()
    try:
        db.merge(portfolio_item)
        db.commit()
    except SQLAlchemyError as e:
        db.rollback()
        raise e
    finally:
        db.close()

def delete_portfolio_item(portfolio_item: Portfolio):
    db: Session = SessionLocal()
    try:
        db.delete(portfolio_item)
        db.commit()
    except SQLAlchemyError as e:
        db.rollback()
        raise e
    finally:
        db.close()