from sqlalchemy.orm import Session
from dao.models import User
from database.database import SessionLocal

def create_user(new_user: User):
    # Create a new session instance
    db: Session = SessionLocal()
    try:
        # Check if user already exists
        existing_user = db.query(User).filter(User.email == new_user.email).first()
        if not existing_user:
            db.add(new_user)
            db.commit()
            db.refresh(new_user)
            return new_user
        return None  # User already exists
    finally:
        db.close()  # Ensure the session is closed after the operation

# function to get the user ID from the database
def retrieve_user_id(email: str):
    db: Session = SessionLocal()
    user = db.query(User).filter(User.email == email).first()  # Query user by email
    return user.id if user else None  # Return user ID or None if not found     