from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from authlib.integrations.starlette_client import OAuth
import jwt
from starlette.middleware.sessions import SessionMiddleware
from auth import create_access_token, verify_token
import os
from dotenv import load_dotenv
from services import stock_service # service layer
from services import portfolio_service # service layer
from pydantic_model.forms import UserCreate, StockRecord, BaseModel
from dependencies import get_current_user_email
from datetime import datetime, timedelta
from jose import JWTError, jwt
from google.oauth2 import id_token
from google.auth.transport import requests


app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Allow requests from your Next.js app
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)


load_dotenv()  # Load environment variables

# Add session middleware
app.add_middleware(SessionMiddleware, secret_key=os.getenv('SECRET_KEY'))

# Configure OAuth2 for Google
oauth = OAuth()
oauth.register(
    name='google',
    client_id=os.getenv('GOOGLE_CLIENT_ID'),
    client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    authorize_params=None,
    access_token_url='https://accounts.google.com/o/oauth2/token',
    access_token_params=None,
    jwks_uri='https://www.googleapis.com/oauth2/v3/certs',
    client_kwargs={'scope': 'openid profile email'},
    userinfo_endpoint='https://openidconnect.googleapis.com/v1/userinfo',
)

# Secret key and algorithm for JWT
SECRET_KEY = os.getenv('SECRET_KEY')
GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30  # Token expiration time in minutes

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

@app.get('/login')
async def login(request: Request):
    redirect_uri = 'http://localhost:8000/auth'  # Redirect after login
    return await oauth.google.authorize_redirect(request, redirect_uri)

@app.get('/auth')
async def auth(request: Request):
    print("Received request for authorization" )
    token = await oauth.google.authorize_access_token(request)
    # Log the token response to ensure 'id_token' is present
    id_token_jwt  = token.get('id_token')

    # Check if the 'id_token' is present in the token response
    if not id_token_jwt:
        raise HTTPException(status_code=400, detail="ID token not found in the response")
    response = None
    # Decode the token
    try:
        decoded_token = id_token.verify_oauth2_token(id_token_jwt, requests.Request(), GOOGLE_CLIENT_ID)

        # Note: Changed 'HS256' to 'RS256' as Google typically uses RS256
        # Remove the 'audience' parameter if it's not needed
    except JWTError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {str(e)}")

    # Continue processing user info
    user_email = decoded_token.get('email')
    user_data = UserCreate(email=user_email, name=None)
    portfolio_service.create_user(user_data)
    try:
        access_token = create_access_token(data={"sub": user_email})
    except Exception as e:
        print(f"Error during token creation: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {e}")
    response = RedirectResponse(url=f"http://localhost:3000/dashboard?token={access_token}")

    return response

@app.get("/portfolio")
def get_portfolio(email: str = Depends(get_current_user_email)):
    return portfolio_service.retrieve_portfolio(email)

@app.post('/portfolio/buy')
async def buy_stock(stock_record: StockRecord, email: str = Depends(get_current_user_email)):
    portfolio_service.create_portfolio(stock_record, email)

@app.post('/portfolio/sell')
async def sell_stock(stock_record: StockRecord, email: str = Depends(get_current_user_email)):
    try:
        result = portfolio_service.sell_stock(stock_record, email)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/stocks/top-gainers")
def get_top_gainers():
     # Fetch the top gainers from Yahoo Finance
    top_gainers = stock_service.get_top_sp500_stocks()

    # Return only the top 10 gainers
    return top_gainers[:10]

@app.get("/stocks/top-losers")
def get_top_losers():
     # Fetch the top gainers from Yahoo Finance
    top_losers = stock_service.get_top_sp500_stocks(False)

    # Return only the top 10 gainers
    return top_losers[:10]

# Main execution
if __name__ == "__main__":
    # Get top gainers
    records = portfolio_service.retrieve_portfolio("vreddy2020@gmail.com")
    print(records[0])