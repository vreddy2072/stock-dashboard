import StockDashboard from './dashboard';

export const metadata = {
  title: 'Stocks Dashboard',
  description: 'Login page for the Stocks Dashboard',
};

export default function Dashboard() {
  return <StockDashboard/>;
}