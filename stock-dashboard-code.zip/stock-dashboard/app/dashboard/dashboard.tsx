'use client'

import React, { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowUpIcon, ArrowDownIcon, TrendingUpIcon, TrendingDownIcon } from 'lucide-react'
import { toast } from "@/components/ui/use-toast"

interface Stock {
  symbol: string
  name: string
  price: number
  previous_close: number
  change_percentage: number
}

interface Stock_T {
  stock_symbol: string
  purchase_price: number
  current_price: number
  quantity: number
  purchase_date: string
  gains_loss: number
}

interface Stock_N {
  stock_symbol: string
  purchase_price: number
  quantity: number
  purchase_date: string
}

export default function Dashboard() {
  const [topGainers, setTopGainers] = useState<Stock[]>([])
  const [topLosers, setTopLosers] = useState<Stock[]>([])
  const [portfolio, setPortfolio] = useState<Stock_T[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [buyModalOpen, setBuyModalOpen] = useState<boolean>(false)
  const [sellModalOpen, setSellModalOpen] = useState<boolean>(false)
  const [newStock, setNewStock] = useState<Stock_N>({ stock_symbol: '', purchase_price: 0, quantity: 0, purchase_date: '' })
  const [sellStock, setSellStock] = useState<{ stock_symbol: string, quantity: number, purchase_price: number }>({ stock_symbol: '', quantity: 0, purchase_price: 0 })
  const [totalGainsLoss, setTotalGainsLoss] = useState<number>(0)

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const token = urlParams.get('token')
    if (token) {
      localStorage.setItem('access_token', token)
      window.history.replaceState({}, document.title, "/dashboard")
    }

    fetchStocks()
    fetchPortfolio()
  }, [])

  const fetchStocks = async () => {
    try {
      const [gainersResponse, losersResponse] = await Promise.all([
        fetch('http://localhost:8000/stocks/top-gainers'),
        fetch('http://localhost:8000/stocks/top-losers')
      ])
      const [gainersData, losersData] = await Promise.all([
        gainersResponse.json(),
        losersResponse.json()
      ])
      setTopGainers(gainersData)
      setTopLosers(losersData)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch stock data:', error)
      setLoading(false)
    }
  }

  const fetchPortfolio = async () => {
    try {
      const token = localStorage.getItem("access_token")
      const response = await fetch('http://localhost:8000/portfolio', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      const data = await response.json()
      setPortfolio(data)
      const total = data.reduce((sum: number, stock: Stock_T) => sum + stock.gains_loss, 0)
      setTotalGainsLoss(total)
      setLoading(false)
    } catch (error) {
      console.error('Failed to fetch portfolio:', error)
      setLoading(false)
    }
  }

  const handleBuy = async () => {
    try {
      const token = localStorage.getItem("access_token")
      console.log("Buy info",JSON.stringify(newStock))
      const response = await fetch('http://localhost:8000/portfolio/buy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newStock),
      })
      if (response.ok) {
        toast({
          title: "Stock purchased successfully",
          description: `You have purchased ${newStock.quantity} shares of ${newStock.stock_symbol}`,
        })
        fetchPortfolio()
        setNewStock({ stock_symbol: '', purchase_price: 0, quantity: 0, purchase_date: '' })
        setBuyModalOpen(false)
      } else {
        const errorData = await response.json()
        toast({
          title: "Failed to purchase stock",
          description: errorData.detail || "An error occurred while purchasing the stock",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error buying stock:', error)
      toast({
        title: "Error",
        description: "An unexpected error occurred while purchasing the stock",
        variant: "destructive",
      })
    }
  }

  const handleSell = async () => {
    try {
      const token = localStorage.getItem("access_token")
      // Set the current date
      const currentDate = new Date().toISOString().split('T')[0]
      const sellData = { ...sellStock, purchase_date: currentDate }
      console.log("Sell info", JSON.stringify(sellData))
      const response = await fetch('http://localhost:8000/portfolio/sell', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(sellData),
      })
      if (response.ok) {
        const result = await response.json()
        toast({
          title: "Stock sold successfully",
          description: `You have sold ${sellStock.quantity} shares of ${sellStock.stock_symbol} for $${sellStock.purchase_price} each. Profit/Loss: $${result.profit_loss.toFixed(2)}`,
        })
        fetchPortfolio()
        setSellStock({ stock_symbol: '', quantity: 0, purchase_price: 0 })
        setSellModalOpen(false)
      } else {
        const errorData = await response.json()
        toast({
          title: "Failed to sell stock",
          description: errorData.detail || "An error occurred while selling the stock",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error selling stock:', error)
      toast({
        title: "Error",
        description: "An unexpected error occurred while selling the stock",
        variant: "destructive",
      })
    }
  }

  const openBuyDialog = () => {
    setBuyModalOpen(true)
  }

  const openSellDialog = () => {
    setSellModalOpen(true)
  }

  return (
    <div className="flex h-screen p-4 gap-4">
      <Card className="w-3/5 overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-2xl font-bold">My Portfolio</CardTitle>
          <div className="space-x-2">
            <Button className="bg-green-500 hover:bg-green-600 text-white" onClick={openBuyDialog}>Buy</Button>
            <Button 
              className="bg-red-500 hover:bg-red-600 text-white" 
              onClick={openSellDialog}
              style={{ backgroundColor: 'rgb(239 68 68)', color: 'white' }}
            >
              Sell
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center">Loading portfolio...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Purchase Price</TableHead>
                  <TableHead>Current Price</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Purchase Date</TableHead>
                  <TableHead>Gains/Loss</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {portfolio.map((stock) => (
                  <TableRow key={stock.stock_symbol}>
                    <TableCell>{stock.stock_symbol}</TableCell>
                    <TableCell>${stock.purchase_price.toFixed(2)}</TableCell>
                    <TableCell>${stock.current_price.toFixed(2)}</TableCell>
                    <TableCell>{stock.quantity}</TableCell>
                    <TableCell>{stock.purchase_date}</TableCell>
                    <TableCell className={stock.gains_loss >= 0 ? 'text-green-600' : 'text-red-600'}>
                      ${stock.gains_loss.toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              <TableFooter>
                <TableRow>
                  <TableCell colSpan={5} className="text-right font-bold">Total Gains/Loss:</TableCell>
                  <TableCell className={`font-bold ${totalGainsLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    ${totalGainsLoss.toFixed(2)}
                  </TableCell>
                </TableRow>
              </TableFooter>
            </Table>
          )}
        </CardContent>
      </Card>
      <div className="w-2/5 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUpIcon className="mr-2 text-green-500"/>
              Top 5 Stocks with Highest Increase
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center">Loading top gainers...</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Today's Price</TableHead>
                    <TableHead>Change (%)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topGainers.map((stock) => (
                    <TableRow key={stock.symbol}>
                      <TableCell>{stock.symbol}</TableCell>
                      <TableCell>{stock.name}</TableCell>
                      <TableCell>${stock.price.toFixed(2)}</TableCell>
                      <TableCell className="text-green-600">
                        <ArrowUpIcon className="inline mr-1" />
                        {stock.change_percentage.toFixed(2)}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingDownIcon className="mr-2 text-red-500" />
              Top 5 Stocks with Highest Decrease
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center">Loading top losers...</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Today's Price</TableHead>
                    <TableHead>Change (%)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topLosers.map((stock) => (
                    <TableRow key={stock.symbol}>
                      <TableCell>{stock.symbol}</TableCell>
                      <TableCell>{stock.name}</TableCell>
                      <TableCell>${stock.price.toFixed(2)}</TableCell>
                      <TableCell className="text-red-600">
                        <ArrowDownIcon className="inline mr-1" />
                        {Math.abs(stock.change_percentage).toFixed(2)}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
      {buyModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-5 rounded-lg shadow-lg w-96">
            <h2 className="text-xl mb-4">Buy Stock</h2>
            <div className="relative mb-4">
              <input
                type="text"
                id="symbol"
                value={newStock.stock_symbol}
                onChange={(e) => setNewStock({ ...newStock, stock_symbol: e.target.value })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Symbol"
              />
              <label
                htmlFor="symbol"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Symbol
              </label>
            </div>
            <div className="relative mb-4">
              <input
                type="number"
                id="price"
                value={newStock.purchase_price}
                onChange={(e) => setNewStock({ ...newStock, purchase_price: Number(e.target.value) })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Price"
              />
              <label
                htmlFor="price"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Price
              </label>
            </div>
            <div className="relative mb-4">
              <input
                type="number"
                id="quantity"
                value={newStock.quantity}
                onChange={(e) => setNewStock({ ...newStock, quantity: Number(e.target.value) })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Quantity"
              />
              <label
                htmlFor="quantity"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Quantity
              </label>
            </div>
            <div className="relative mb-4">
              <input
                type="date"
                id="buyDate"
                value={newStock.purchase_date}
                onChange={(e) => setNewStock({ ...newStock, purchase_date: e.target.value })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Buy Date"
              />
              <label
                htmlFor="buyDate"
                className="absolute left-2 top-2  text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Buy Date
              </label>
            </div>
            <div className="flex justify-end">
              <button onClick={handleBuy} className="bg-green-500 text-white rounded px-4 py-2 hover:bg-green-600 transition duration-300">Confirm</button>
              <button onClick={() => setBuyModalOpen(false)} className="bg-red-500 text-white rounded px-4 py-2 ml-2 hover:bg-red-600 transition duration-300">Cancel</button>
            </div>
          </div>
        </div>
      )}
      {sellModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-5 rounded-lg shadow-lg w-96">
            <h2 className="text-xl mb-4">Sell Stock</h2>
            <div className="relative mb-4">
              <input
                type="text"
                id="sellSymbol"
                value={sellStock.stock_symbol}
                onChange={(e) => setSellStock({ ...sellStock, stock_symbol: e.target.value })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Symbol"
              />
              <label
                htmlFor="sellSymbol"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Symbol
              </label>
            </div>
            <div className="relative mb-4">
              <input
                type="number"
                id="sellQuantity"
                value={sellStock.quantity}
                onChange={(e) => setSellStock({ ...sellStock, quantity: Number(e.target.value) })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Quantity"
              />
              <label
                htmlFor="sellQuantity"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Quantity
              </label>
            </div>
            <div className="relative mb-4">
              <input
                type="number"
                id="sellPrice"
                value={sellStock.purchase_price}
                onChange={(e) => setSellStock({ ...sellStock, purchase_price: Number(e.target.value) })}
                className="peer border rounded p-2 w-full pt-6 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Sell Price"
              />
              <label
                htmlFor="sellPrice"
                className="absolute left-2 top-2 text-gray-600 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:top-2 peer-focus:text-sm"
              >
                Sell Price
              </label>
            </div>
            <div className="flex justify-end">
              <button onClick={handleSell} className="bg-green-500 text-white rounded px-4 py-2 hover:bg-green-600 transition duration-300">Confirm</button>
              <button onClick={() => setSellModalOpen(false)} className="bg-red-500 text-white rounded px-4 py-2 ml-2 hover:bg-red-600 transition duration-300">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}