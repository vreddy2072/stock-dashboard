import React from 'react';
import { LoginButton } from './LoginButton';

export const metadata = {
  title: 'Stocks Dashboard - Login',
  description: 'Login page for the Stocks Dashboard',
};

const LoginPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-pink-100 to-blue-100">
      <div className="p-10 bg-white shadow-lg rounded-lg text-center">
        <h1 className="text-3xl font-bold mb-5 text-blue-600">Login to Stocks Dashboard</h1>
        <LoginButton />
      </div>
    </div>
  );
};

export default LoginPage;