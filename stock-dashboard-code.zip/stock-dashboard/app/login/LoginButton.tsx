"use client";

import React from 'react';
import { LucideLogIn } from 'lucide-react';

export const LoginButton = () => {
  const handleLogin = () => {
    window.location.href = 'http://localhost:8000/login'; // FastAPI login route
  };

  return (
    <button
      onClick={handleLogin}
      className="flex items-center px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg shadow-md"
    >
      <LucideLogIn className="mr-2" />
      Sign in with Google
    </button>
  );
};
